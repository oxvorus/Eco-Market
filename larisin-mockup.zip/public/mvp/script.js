// CTA handlers
document.addEventListener("DOMContentLoaded", () => {
  const go = (path) => {
    // respect <base href="/mvp/">, so "path" is relative to /mvp/
    window.location.href = path
  }

  const explore = document.getElementById("cta-explore")
  if (explore) explore.addEventListener("click", () => go("marketplace.html"))

  const login = document.getElementById("cta-login")
  if (login) login.addEventListener("click", () => go("login.html"))
})

// Bubbles interactive effect
const bubbles = document.getElementById("bubbles")
function isInteractive(el) {
  return !!el.closest("a, button, input, select, textarea, nav")
}
function spawnBubble(x, y, alt) {
  const b = document.createElement("div")
  b.className = "bubble" + (alt ? " bubble--alt" : "")
  b.style.left = x + "px"
  b.style.top = y + "px"
  bubbles.appendChild(b)
  b.addEventListener("animationend", () => b.remove())
}

document.addEventListener("click", (e) => {
  if (!bubbles) return
  // Ignore clicks on interactive elements
  if (isInteractive(e.target)) return
  const { clientX, clientY } = e
  for (let i = 0; i < 5; i++) {
    const dx = (Math.random() - 0.5) * 40
    const dy = (Math.random() - 0.5) * 20
    const alt = i % 2 === 0
    spawnBubble(clientX + dx, clientY + dy, alt)
  }
})
